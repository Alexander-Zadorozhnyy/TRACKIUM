from flet import padding
base_height = 900
base_width = 420
btn_width = 350
btn_height = 50
br = 30
bnt_size = 9
base_color = '#1b1517'
input_fill_color = "#ffffff"
base_green = "#01c38e"
light_green = "#e5f8f2"
input_hint_color = '#75797c'
content_padding = padding.only(left=20,top=10,right=10,bottom=10)
input_error_bg = "#f8c1bc"
input_error_outline = "#cb1a2a"
img_src ='https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80'