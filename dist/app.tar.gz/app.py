from flet import *

from TRUCKIUM.db.TRUCKIUMDatabase import TRUCKIUMDatabase
from views import views_handler

from TRUCKIUM.utils.config import DEVICE_HEIGHT, DEVICE_WIDTH


class CurrentUser:
    def __init__(self, db, user_id=None, user_name=None, car=None, deal=None):
        self.db = db
        self.user_id = user_id
        self.user_name = user_name
        self.car = car
        self.deal = deal


class App(UserControl):
    def __init__(self, pg: Page):
        super().__init__()

        pg.window_title_bar_hidden = True
        pg.window_frameless = True
        pg.window_title_bar_buttons_hidden = True
        pg.window_movable = True
        pg.bgcolor = colors.TRANSPARENT
        pg.window_bgcolor = colors.TRANSPARENT
        pg.fonts = {
            "Poppins ThinItalic": "fonts/poppins/Poppins-ThinItalic.ttf",
            "Poppins Thin": "fonts/poppins/Poppins-Thin.ttf",
            "Poppins Semibold": "fonts/poppins/Poppins-Semibold.ttf",
            "Poppins SemiboldItalic": "fonts/poppins/Poppins-SemiboldItalic.ttf",
            "Poppins Regular": "fonts/poppins/Poppins-Regular.ttf",
            "Poppins MediumItalic": "fonts/poppins/Poppins-MediumItalic.ttf",
            "Poppins Medium": "fonts/poppins/Poppins-Medium.ttf",
            "Poppins LightItalic": "fonts/poppins/Poppins-LightItalic.ttf",
            "Poppins Light": "fonts/poppins/Poppins-Light.ttf",
            "Poppins Italic": "fonts/poppins/Poppins-Italic.ttf",
            "Poppins ExtraLightItalic": "fonts/poppins/Poppins-ExtraLightItalic.ttf",
            "Poppins ExtraLight": "fonts/poppins/Poppins-ExtraLight.ttf",
            "Poppins ExtraBold": "fonts/poppins/Poppins-ExtraBold.ttf",
            "Poppins ExtraBoldItalic": "fonts/poppins/Poppins-ExtraBoldItalic.ttf",
            "Poppins BoldItalic": "fonts/poppins/Poppins-BoldItalic.ttf",
            "Poppins Bold": "fonts/poppins/Poppins-Bold.ttf",
            "Poppins BlackItalic": "fonts/poppins/Poppins-BlackItalic.ttf",
            "Poppins Black": "fonts/poppins/Poppins-Black.ttf",
        }
        pg.window_min_height = DEVICE_HEIGHT
        pg.window_min_width = DEVICE_WIDTH
        pg.window_height = DEVICE_HEIGHT
        pg.window_width = DEVICE_WIDTH

        db = TRUCKIUMDatabase()
        db.connect_to_database()

        self.user = CurrentUser(db)

        pg.on_route_change = self.route_change

        self.pg = pg
        self.pg.go('/start_page')

    def route_change(self, route):
        print(self.pg.route)
        self.pg.views.clear()
        self.pg.views.append(
            views_handler(self.pg, self.user)[self.pg.route]
        )


# def main(page: Page):
#     def route_change(route):
#         print(page.route)
#         page.views.clear()
#         page.views.append(
#             views_handler(page)[page.route]
#         )
#
#     page.on_route_change = route_change
#     page.go('/start_page')


if __name__ == "__main__":
    app(target=App, assets_dir='assets')
