# host = "127.0.0.1"
# user = "postgres"
# password = "123sasha456"
# db_name = "truckium_new"

host = "dpg-cgt5rhl269vbmesuapn0-a.oregon-postgres.render.com"
user = "admin"
password = "JAxVoO3oYMC5681LPi3FXYUk96hZvcsj"
db_name = "db_truckium"

# postgres://admin:JAxVoO3oYMC5681LPi3FXYUk96hZvcsj@dpg-cgt5rhl269vbmesuapn0-a.oregon-postgres.render.com/db_truckium